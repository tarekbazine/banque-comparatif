<footer>
    <div class="row">
        <div class="col-md-4">
        </div>
        <div class="col-md-2">
            <ul>
                <li>
                    <a href="<?=URL?>">Accueil</a>
                </li>
                <li>
                    <a href="comparatif">Comparatif</a>
                </li>
            </ul>
        </div>
        <div class="col-md-2">
            <ul>
                <li>
                    <a href="qui_sommes_nous">Qui sommes-nous</a>
                </li>
            </ul>
        </div>

    </div>
</footer>
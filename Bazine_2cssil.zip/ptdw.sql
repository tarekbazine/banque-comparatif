-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Ven 19 Janvier 2018 à 23:00
-- Version du serveur :  5.7.11-log
-- Version de PHP :  7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ptdw`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `mot_de_passe` varchar(256) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Contenu de la table `admin`
--

INSERT INTO `admin` (`id`, `nom`, `mot_de_passe`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'me', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Structure de la table `banque`
--

CREATE TABLE `banque` (
  `id_banque` int(8) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `siege_social` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `id_gestion_compte` int(11) NOT NULL,
  `id_operations_paiement` int(11) NOT NULL,
  `id_monetique` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `banque`
--

INSERT INTO `banque` (`id_banque`, `nom`, `siege_social`, `telephone`, `fax`, `id_gestion_compte`, `id_operations_paiement`, `id_monetique`) VALUES
(1, 'BANQUE EXTÉRIEURE D’ALGÉRIE « BEA »', '48, Rue des Frères Bouadou,\r\nBir Mourad Raïs – Alger', '021 56 25 70', '021 56 30 50 / 56 51 54', 1, 1, 1),
(2, 'BANQUE NATIONALE D’ALGÉRIE « BNA »', '8, Boulevard Ernesto Che Guevara, Alger', '021 43 99 98', '021 43 94 94', 2, 2, 2),
(3, 'BANQUE DE L’AGRICULTURE ET DU DÉVELOPPEMENT RURAL « BADR »', '17, Boulevard Colonel Amirouche, Alger', '021 64 26 70 ', '021 63 51 46 / 64 34 44', 3, 3, 3),
(4, 'BANQUE DE DÉVELOPPEMENT LOCAL « BDL »', '5, rue Gaci Amar, Staoueli, Alger', '021 39 34 89', '021 39 37 57', 4, 4, 4),
(5, 'CRÉDIT POPULAIRE D’ALGÉRIE « CPA »', '2, Boulevard Colonel Amirouche, Alger', '021 63 57 12', '021 63 56 98', 5, 5, 5),
(6, 'CAISSE D’ÉPARGNE ET DE PRÉVOYANCE « CNEP BANQUE »', 'Lot n°2 Garidi, Kouba – Alger', '021 28 47 38', '021 28 47 35', 6, 6, 6),
(8, 'ARAB BANKING CORPORATION ALGERIE « ABC »', '4, Avenue des Trois Frères Bouadou (ex ravin de la femme sauvage) Bir Mourad Rais, Alger', '021 LD 54 03 45 / 54 01 83 / 54 15 15 / 54 15 34 / 54 14 37 / 54 16 00', '021 54 16 04', 8, 8, 8),
(9, 'NATIXIS BANQUE', '62, Chemin Drareni, Hydra, Alger', '023 92 41 23', '023 92 41 51 / 43 43', 9, 9, 9),
(10, 'SOCIÉTÉ GENERALE ALGÉRIE', 'Résidence El Karma 16105 Gué de Constantine -Alger- BP : 55 Bir Khadem', '021 45 13 70', '021 45 13 75', 10, 10, 10),
(11, 'ARAB BANK PLC ALGERIA (succursale de banque)', 'Boulevard Benyoucef Benkhedda, Sidi Yahia n°46 – Alger', ' 021 48 49 26 / 48 00 02 / 48 00 03', '021 48 00 01 / LD : 021 60 49 86', 11, 11, 11),
(12, 'B.N.P.-PARIBAS EL DJAZAIR', '10, Rue Abou Nouas, Hydra – Alger', '021 60 39 42 / 60 39 29', '021 60 72 19 / LD : 021 48 05 75', 12, 12, 12),
(13, 'TRUST BANK ALGERIA', '70, Chemin Larbi Allik, Hydra – Alger – BP 772', '021 54 97 55', '021 54 97 50', 13, 13, 13),
(14, 'GULF BANK ALGERIA', 'Haouche Route de Chéraga, BP 26 bis Delly Ibrahim – Alger', '021 91 00 31 – 91 08 76', '021 91 02 64 / 91 74 10', 14, 14, 14);

-- --------------------------------------------------------

--
-- Structure de la table `gestion_tenue_compte`
--

CREATE TABLE `gestion_tenue_compte` (
  `id_gestion_compte` int(11) NOT NULL,
  `ouverture_compte_delivrance_chequier` int(11) NOT NULL DEFAULT '0',
  `frais_tenue_compte_courant` int(11) NOT NULL DEFAULT '0',
  `frais_tenue_compte_professionnel` int(11) NOT NULL DEFAULT '0',
  `frais_tenue_compte_cheque` int(11) NOT NULL DEFAULT '0',
  `frais_tenue_compte_sur_livret` int(11) NOT NULL DEFAULT '0',
  `tenue_compte_en_devise` int(11) NOT NULL DEFAULT '0',
  `fermeture_compte_courant` int(11) NOT NULL DEFAULT '0',
  `fermeture_compte_cheque` int(11) NOT NULL DEFAULT '0',
  `fermeture_compte_sur_livret` int(11) NOT NULL DEFAULT '0',
  `fermeture_compte_devise` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `gestion_tenue_compte`
--

INSERT INTO `gestion_tenue_compte` (`id_gestion_compte`, `ouverture_compte_delivrance_chequier`, `frais_tenue_compte_courant`, `frais_tenue_compte_professionnel`, `frais_tenue_compte_cheque`, `frais_tenue_compte_sur_livret`, `tenue_compte_en_devise`, `fermeture_compte_courant`, `fermeture_compte_cheque`, `fermeture_compte_sur_livret`, `fermeture_compte_devise`) VALUES
(1, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 3, 11, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 99, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(10, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(13, 88, 99, 0, 0, 0, 0, 0, 0, 0, 0),
(14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `monetique`
--

CREATE TABLE `monetique` (
  `id_monetique` int(11) NOT NULL,
  `carte_cib` int(11) NOT NULL DEFAULT '0',
  `emission_premiere_carte` int(11) NOT NULL DEFAULT '0',
  `renouvelement` int(11) NOT NULL DEFAULT '0',
  `reconfection` int(11) NOT NULL DEFAULT '0',
  `reedition_code_secret` int(11) NOT NULL DEFAULT '0',
  `comission_retrait_sur_dab_banque` int(11) NOT NULL DEFAULT '0',
  `comission_retrait_sur_dab_confrere` int(11) NOT NULL DEFAULT '0',
  `commission_paiement_sur_tpe_client` int(11) DEFAULT '0',
  `commission_paiement_sur_tpe_commercant` int(11) NOT NULL DEFAULT '0',
  `carte_internationale` int(11) NOT NULL DEFAULT '0',
  `octroi` int(11) NOT NULL DEFAULT '0',
  `mise_en_opposition` int(11) NOT NULL DEFAULT '0',
  `re_confection` int(11) NOT NULL DEFAULT '0',
  `reedition_du_code_secret` int(11) NOT NULL DEFAULT '0',
  `changement_de_code_pin` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `monetique`
--

INSERT INTO `monetique` (`id_monetique`, `carte_cib`, `emission_premiere_carte`, `renouvelement`, `reconfection`, `reedition_code_secret`, `comission_retrait_sur_dab_banque`, `comission_retrait_sur_dab_confrere`, `commission_paiement_sur_tpe_client`, `commission_paiement_sur_tpe_commercant`, `carte_internationale`, `octroi`, `mise_en_opposition`, `re_confection`, `reedition_du_code_secret`, `changement_de_code_pin`) VALUES
(1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 9982, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 20, 55, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, 10, 222, 3333, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `operation_paiement`
--

CREATE TABLE `operation_paiement` (
  `id_operation` int(11) NOT NULL,
  `versement_especes_client_agence` int(11) NOT NULL DEFAULT '0',
  `versement_especes_tiers` int(11) NOT NULL DEFAULT '0',
  `versement_especes_deplace_lient_autre_agence` int(11) NOT NULL DEFAULT '0',
  `virement_recu_compte_meme_agence` int(11) NOT NULL DEFAULT '0',
  `virement_recu_compte_autre_agence_meme_banque` int(11) NOT NULL DEFAULT '0',
  `virement_devise_recu_etranger` int(11) NOT NULL DEFAULT '0',
  `rertait_especes` int(11) NOT NULL DEFAULT '0',
  `retrait_especes_guichets_autre_agence` int(11) NOT NULL DEFAULT '0',
  `emission_cheque_banque` int(11) NOT NULL DEFAULT '0',
  `emission_cheque_banque_deplace` int(11) NOT NULL DEFAULT '0',
  `annulation_cheque_banque` int(11) NOT NULL DEFAULT '0',
  `virement_compte_compte` int(11) NOT NULL DEFAULT '0',
  `virement_ordonne_en_faveur_client_autre_agence` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `operation_paiement`
--

INSERT INTO `operation_paiement` (`id_operation`, `versement_especes_client_agence`, `versement_especes_tiers`, `versement_especes_deplace_lient_autre_agence`, `virement_recu_compte_meme_agence`, `virement_recu_compte_autre_agence_meme_banque`, `virement_devise_recu_etranger`, `rertait_especes`, `retrait_especes_guichets_autre_agence`, `emission_cheque_banque`, `emission_cheque_banque_deplace`, `annulation_cheque_banque`, `virement_compte_compte`, `virement_ordonne_en_faveur_client_autre_agence`) VALUES
(1, 200, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(13, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `presentation`
--

CREATE TABLE `presentation` (
  `id_presentation` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `resume` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `tel` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `presentation`
--

INSERT INTO `presentation` (`id_presentation`, `titre`, `resume`, `image`, `tel`, `fax`, `address`, `logo`) VALUES
(1, 'qui sommes nous', 'Banque Comparatif Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'front/img/slides/slide-4.jpg', '023.99.99.99', '023.00.00.00', 'OUED EL SAMAR 999 CITY CITY - ALGER', 'front/img/logo.png');

-- --------------------------------------------------------

--
-- Structure de la table `slide_show`
--

CREATE TABLE `slide_show` (
  `id_image` int(11) NOT NULL,
  `duree_aparition` int(11) NOT NULL,
  `lien` varchar(255) NOT NULL,
  `discription` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `slide_show`
--

INSERT INTO `slide_show` (`id_image`, `duree_aparition`, `lien`, `discription`) VALUES
(1, 2, 'front/img/slides/slide-1.png', 'img'),
(2, 2, 'front/img/slides/slide-2.png', 'img2'),
(3, 2, 'front/img/slides/slide-4.png', 'img'),
(4, 2, 'front/img/slides/slide-5.png', 'img');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `banque`
--
ALTER TABLE `banque`
  ADD PRIMARY KEY (`id_banque`),
  ADD KEY `id_gestion_compte` (`id_gestion_compte`),
  ADD KEY `id_operations_paiement` (`id_operations_paiement`),
  ADD KEY `id_monetique` (`id_monetique`);

--
-- Index pour la table `gestion_tenue_compte`
--
ALTER TABLE `gestion_tenue_compte`
  ADD PRIMARY KEY (`id_gestion_compte`);

--
-- Index pour la table `monetique`
--
ALTER TABLE `monetique`
  ADD PRIMARY KEY (`id_monetique`);

--
-- Index pour la table `operation_paiement`
--
ALTER TABLE `operation_paiement`
  ADD PRIMARY KEY (`id_operation`);

--
-- Index pour la table `presentation`
--
ALTER TABLE `presentation`
  ADD PRIMARY KEY (`id_presentation`);

--
-- Index pour la table `slide_show`
--
ALTER TABLE `slide_show`
  ADD PRIMARY KEY (`id_image`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `banque`
--
ALTER TABLE `banque`
  MODIFY `id_banque` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `gestion_tenue_compte`
--
ALTER TABLE `gestion_tenue_compte`
  MODIFY `id_gestion_compte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `monetique`
--
ALTER TABLE `monetique`
  MODIFY `id_monetique` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `operation_paiement`
--
ALTER TABLE `operation_paiement`
  MODIFY `id_operation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `presentation`
--
ALTER TABLE `presentation`
  MODIFY `id_presentation` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `slide_show`
--
ALTER TABLE `slide_show`
  MODIFY `id_image` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `banque`
--
ALTER TABLE `banque`
  ADD CONSTRAINT `banque_ibfk_1` FOREIGN KEY (`id_operations_paiement`) REFERENCES `operation_paiement` (`id_operation`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `banque_ibfk_2` FOREIGN KEY (`id_gestion_compte`) REFERENCES `gestion_tenue_compte` (`id_gestion_compte`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `banque_ibfk_3` FOREIGN KEY (`id_monetique`) REFERENCES `monetique` (`id_monetique`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

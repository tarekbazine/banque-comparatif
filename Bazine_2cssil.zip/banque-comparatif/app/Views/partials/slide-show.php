<div class="diaporama">
    <img id="img01" src="front/img/slides/slide-2.jpg" alt="entreprise img" title="image3">
    <img id="img0" src="front/img/slides/slide-5.jpg" alt="entreprise img" title="image4">
    <img id="img1" src="front/img/slides/slide-3.jpg" alt="entreprise img" title="image1">
    <img id="img2" src="front/img/slides/slide-1.png" alt="entreprise img" title="image2">
    <img id="img3" src="front/img/slides/slide-2.jpg" alt="entreprise img" title="image3">
    <img id="img4" src="front/img/slides/slide-5.jpg" alt="entreprise img" title="image4">
</div>